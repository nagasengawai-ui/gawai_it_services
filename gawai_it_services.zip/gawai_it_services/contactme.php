<?php
require("./mailing/mailfunction.php");

/* Form Data */
$name    = $_POST["name"] ?? '';
$phone   = $_POST["phone"] ?? '';
$email   = $_POST["email"] ?? '';
$message = $_POST["message"] ?? '';

/* Receiver Email */
$receiverEmail = "nagasengawai@gmail.com";

/* Mail Body */
$body = "
<h2>New Contact Form Submission</h2>
<ul>
    <li><strong>Name:</strong> $name</li>
    <li><strong>Phone:</strong> $phone</li>
    <li><strong>Email:</strong> $email</li>
    <li><strong>Message:</strong> $message</li>
</ul>
";

/* Send Email */
$status = mailfunction($receiverEmail, "Naraga IT Solutions - New Inquiry", $body);

if ($status) {

    /* WhatsApp Number (with country code, India = 91) */
    $whatsappNumber = "9196999214019";

    /* WhatsApp Message */
    $whatsappMsg = urlencode(
        "Hello Naraga IT Solutions 👋\n\n".
        "New Contact Form Inquiry:\n\n".
        "Name: $name\n".
        "Phone: $phone\n".
        "Email: $email\n".
        "Message: $message"
    );

    /* Redirect to WhatsApp */
    header("Location: https://wa.me/$whatsappNumber?text=$whatsappMsg");
    exit();

} else {
    echo "<center><h1>Error sending message! Please try again.</h1></center>";
}
?>
